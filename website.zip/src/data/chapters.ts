export interface ResearchBlock {
  title: string
  paragraphs: { text: string; sources: string[] }[]
  technical?: boolean
}
export interface Chapter {
  id: number
  title: string
  shortTitle: string
  period: string
  accent: string
  duration: string
  takeaway: string
  introduction: string
  blocks: ResearchBlock[]
}

export const chapters: Chapter[] = [
  {
    "id": 1,
    "title": "Before Vlahos",
    "shortTitle": "Earlier compositing",
    "period": "BEFORE THE LATE 1950s",
    "accent": "blue",
    "duration": "0:35",
    "takeaway": "Earlier blue-screen methods left room for improvement.",
    "introduction": "Vlahos worked on a problem filmmakers already knew: combining separate images without an obvious join.",
    "blocks": [
      {
        "title": "From masks to a finished shot",
        "paragraphs": [
          {
            "text": "Early filmmakers combined exposures using masks that reserved part of the frame for another image. Moving subjects required a changing mask, followed by accurate alignment of the film records. This laboratory work was slow and demanding. Vlahos’s later research concentrated on making separation and reconstruction more reliable.",
            "sources": [
              "S2",
              "S5"
            ]
          },
          {
            "text": "A successful composite also depends on matching perspective, lighting and colour. A precise matte gives the effects department a better starting element; cinematographers and laboratory crews still have to make the separate images fit together.",
            "sources": [
              "S2",
              "S5"
            ]
          }
        ]
      }
    ]
  },
  {
    "id": 2,
    "title": "An engineer enters Hollywood",
    "shortTitle": "Biography",
    "period": "1916–1968",
    "accent": "neutral",
    "duration": "0:50",
    "takeaway": "Industrial engineering led Vlahos into shared studio research.",
    "introduction": "His career connected aircraft manufacture, radar engineering and Hollywood’s laboratories.",
    "blocks": []
  },
  {
    "id": 3,
    "title": "The colour-difference process",
    "shortTitle": "Colour difference",
    "period": "1959 / 1964",
    "accent": "blue",
    "duration": "1:15",
    "takeaway": "Comparing colour records produced more useful mattes.",
    "introduction": "Vlahos improved blue-screen photography by working with the colour information recorded on film.",
    "blocks": [
      {
        "title": "Developing a process for Ben-Hur",
        "paragraphs": [
          {
            "text": "MGM’s Ben-Hur (1959) was photographed on 65 mm film for large-screen exhibition. Foster explains that Vlahos’s sodium system, built around a modified 35 mm Technicolor camera, could not meet that format requirement. MGM asked him to improve blue-screen compositing instead. The Los Angeles Times later clarified that his process contributed to the sea battle and its aftermath.",
            "sources": [
              "S5",
              "S1"
            ]
          }
        ]
      },
      {
        "title": "How Vlahos used colour differences",
        "paragraphs": [
          {
            "text": "Colour film can be separated into photographic records corresponding to red, green and blue information. A saturated blue backing registers strongly in the blue record and weakly in the others. Foreground subjects usually produce a different balance. Vlahos used those relationships to construct travelling mattes and reconstruct foreground colour, reducing the blue border that could remain around an actor.",
            "sources": [
              "S2"
            ]
          },
          {
            "text": "His workflow involved colour separations, positive and negative film records, a synthetic blue record and controlled printing exposures. The masks and images had to stay precisely aligned, a requirement called registration. This gave filmmakers finer control over soft boundaries and reflected backing light while retaining the subject’s colour.",
            "sources": [
              "S2"
            ]
          }
        ]
      },
      {
        "title": "The patent and its influence",
        "paragraphs": [
          {
            "text": "Vlahos filed Composite Color Photography, US 3,158,477, on 2 April 1959; it was granted on 24 November 1964. The filing places the work in the Ben-Hur production period. The process became an important part of optical compositing, and the Academy’s career retrospective traces its later use in films including the original Star Wars trilogy.",
            "sources": [
              "S2",
              "S9"
            ]
          }
        ]
      },
      {
        "title": "Technical notes: film density and RGB values",
        "paragraphs": [
          {
            "text": "Photographic density describes how much light a film record absorbs. Positive and negative records reverse light–dark relationships, and their response depends on exposure and processing. The full process therefore cannot be reduced to one digital subtraction such as “blue minus green.” The patent diagrams show the sequence of photographic operations.",
            "sources": [
              "S2"
            ]
          },
          {
            "text": "The demonstration uses numerical RGB values to make the comparison visible. Its graduated matte estimates partial coverage, while its spill correction reduces reflected backing colour. Vlahos carried out comparable tasks through film records and laboratory printing.",
            "sources": [
              "S2",
              "S4"
            ]
          }
        ],
        "technical": true
      }
    ]
  },
  {
    "id": 4,
    "title": "Sodium vapour and Mary Poppins",
    "shortTitle": "Sodium vapour",
    "period": "1958–1965",
    "accent": "yellow",
    "duration": "1:20",
    "takeaway": "Vlahos’s optical system recorded picture and matte together.",
    "introduction": "A second approach separated the backdrop’s narrow yellow spectrum inside the camera.",
    "blocks": [
      {
        "title": "Vlahos’s optical contribution",
        "paragraphs": [
          {
            "text": "Vlahos filed Composite Photography Utilizing Sodium Vapor Illumination, US 3,095,304, on 15 May 1958. Granted on 25 June 1963, it describes selective optics and simultaneous photographic records. Foster’s interview account credits Vlahos with developing the multilayer-coated prism and Iwerks with adapting the camera for Disney production.",
            "sources": [
              "S3",
              "S5"
            ]
          },
          {
            "text": "A dichroic coating reflects selected wavelengths while transmitting others. Here it isolated the sodium-lit backing near 589 nm from most of the performer’s light. In a modified Technicolor camera, colour film recorded the foreground and black-and-white film recorded the matte. Both received the same view at the same moment, preserving closely matched boundaries for later printing.",
            "sources": [
              "S3",
              "S5"
            ]
          }
        ]
      },
      {
        "title": "Practical limits and parallel work",
        "paragraphs": [
          {
            "text": "The technique needed specialized lamps, precision-coated optics and a modified camera. Those requirements limited its adaptability to other film formats and production workflows. Vlahos’s colour-difference work offered a more flexible route; later electronic keyers could operate on video signals without a dual-film camera.",
            "sources": [
              "S3",
              "S4",
              "S5"
            ]
          },
          {
            "text": "British researchers also developed sodium-backed matting. Ray Harryhausen described using Rank’s process for The 3 Worlds of Gulliver (1960) and Mysterious Island (1961). Vlahos’s patent belongs within that wider history of work on spectral separation.",
            "sources": [
              "S12"
            ]
          }
        ]
      },
      {
        "title": "Technical notes: wavelength and matte polarity",
        "paragraphs": [
          {
            "text": "Low-pressure sodium lamps concentrate their output in narrow spectral lines near 589 nm. The backdrop receives this light; the performer is lit separately with broad-spectrum lamps. An ordinary yellow surface under white light would reflect a much broader spectrum and would not provide the same selective signal.",
            "sources": [
              "S3"
            ]
          },
          {
            "text": "On the sodium record, exposed background areas and the subject’s silhouette provide the information for a matte. Printing can reverse its light–dark polarity to make a complementary mask. Partial transmission through fine or translucent material produces intermediate exposure, helping preserve detail that a hard silhouette would discard.",
            "sources": [
              "S3"
            ]
          }
        ],
        "technical": true
      }
    ]
  },
  {
    "id": 5,
    "title": "Ultimatte and his legacy",
    "shortTitle": "Legacy",
    "period": "1976 → TODAY",
    "accent": "green",
    "duration": "1:00",
    "takeaway": "Vlahos continued refining compositing as production moved into video.",
    "introduction": "His later work brought more precise colour control to electronic film and television workflows.",
    "blocks": [
      {
        "title": "Continuing the work in electronics",
        "paragraphs": [
          {
            "text": "Vlahos’s electronic-compositing patent, US 4,007,487, was filed on 25 September 1975 and granted on 8 February 1977. It addressed uneven backing brightness, shadows, unwanted blue reflections and partly transparent subjects. Electronic keying already existed; his contribution was better control over the faults that made a composite look artificial.",
            "sources": [
              "S4"
            ]
          },
          {
            "text": "Ultimatte extended this research into production equipment. Circuits compared foreground colour signals and controlled their mixture with a background signal, avoiding the repeated film-printing stages of optical compositing. Foster identifies Carl Sagan’s Cosmos as an early television use. Television, once a competitor pushing studios toward spectacle, also became an important setting for Vlahos’s work.",
            "sources": [
              "S4",
              "S5",
              "S8"
            ]
          }
        ]
      },
      {
        "title": "Technical notes: digital cameras and colour",
        "paragraphs": [
          {
            "text": "Many single-sensor digital cameras use a Bayer filter pattern: half the photosites measure green, one quarter red and one quarter blue. Demosaicing estimates the missing components to make a full-colour image. This can favour green-channel detail, although wardrobe, reflections, lighting and camera response also influence the choice of backing.",
            "sources": [
              "S11"
            ]
          },
          {
            "text": "A conventional colour camera measures light, so foreground coverage must be estimated or captured through an additional method. Digital compositing often represents that coverage as alpha: zero reveals the background, one retains the foreground, and intermediate values blend them. Vlahos’s film separations and electronic circuits addressed this separation problem using the recording media available to him.",
            "sources": [
              "S2",
              "S4",
              "S18"
            ]
          }
        ],
        "technical": true
      }
    ]
  }
]
