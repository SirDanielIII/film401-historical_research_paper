# Final content review — Petro Vlahos

Reviewed 16 November 2026 for the FILM 401 historical presentation. The existing design, Berlin Sans fonts, themes, photographs, patent drawings, navigation, demonstrations and narration player were preserved.

## Research foundation

Both DOCX files in `research/` were checked against their text extracts: all 302 paragraphs of the expanded research document and all 47 paragraphs of the refined script were represented. Both extracts were read. The expanded dossier supplied the historical foundation; the refined script informed the presentation sequence. Original research documents and extracts remain unchanged, including their original errors. The corrections below apply to the website and its current recording script.

## Assignment coverage

| Requirement | Location and evidence |
| --- | --- |
| [x] Place of origin | Biography: Raton, New Mexico; born 20 August 1916; timeline. [1] |
| [x] Childhood and education | Biography: move to San Pedro at eight; Berkeley engineering degree, 1941. [1] |
| [x] Career path into special effects | Biography: Douglas Aircraft, Bell Laboratories, MGM sound-director introduction, Motion Picture Research Council, later research-centre appointment. [1] |
| [x] Social context | Biography: television in the home, declining cinema attendance, changing audience expectations. [8] |
| [x] Political context | Biography, “Political pressures on studio work”: Paramount antitrust case, HUAC and blacklisting. [15–16] |
| [x] Historical and industrial context | Biography: shared studio research, labour conflict, widescreen and spectacle; colour-difference section: Ben-Hur’s 65 mm requirements. [5, 8] |
| [x] Significant contributions | Introduction and three invention sections connect production problems to Vlahos’s work. |
| [x] Colour-difference travelling mattes | Colour-difference section: photographic records, reconstruction, registration, US 3,158,477 and RGB/matte comparison. [2] |
| [x] Sodium-vapour process | Sodium section: Vlahos’s prism work, separate actor/backdrop lighting, narrowband separation, synchronized film records and camera limitations. [3, 5] |
| [x] Mary Poppins and collaboration | Case study and Vlahos–Iwerks–Pohl credit; parallel Rank work in the supporting text. [5–7, 12, 17] |
| [x] Ultimatte and electronic compositing | Legacy: company, signal mixing, television use, electronic patent and Petro/Paul recognition. [1, 4–6] |
| [x] Professional legacy | Legacy and honours: Emmy, Gordon E. Sawyer Award, Ultimatte award, later digital practice and modern sodium reconstruction. [1, 6, 9, 14] |
| [x] Historical sources and citations | References: stable numbered sources, claim-specific citations, explicit external links, highlighted/focused citation targets. |
| [x] Visual examples and illustrations | Historical photographs, film stills, patent sheets, RGB/matte demonstration, sodium optical diagram. |
| [x] Five-minute narration | Five current scripts total **668 spoken words**; approximately **4:46 at 140 wpm**, before demonstration pauses. All transcripts and exported script match. Actual delivery requires rehearsal. |
| [x] Supporting Q&A | Further Questions: all 24 answers in seven topic groups; optional glossary and technical notes retained. |

## Historical corrections and qualifications

- **1968 research centre:** corrected the biography and timeline to identify the **Association of Motion Picture and Television Producers**, rather than the Academy, as operator. Nelson’s obituary contains this published correction even though the original sentence remains further down the article. Its career account also supports Vlahos’s intervening management of a military contractor’s physical sciences department.
- **Ben-Hur:** the same correction identifies the **sea battle and aftermath**, rather than chariot scenes. Updated the production explanation, sidebar and Q&A answer 9; removed the obsolete “shot-level evidence not supplied” answer. The still is captioned as a film example without asserting that the pictured shot used his process.
- **Sodium illumination:** the backdrop receives narrowband sodium light near 589 nm; performers receive separate broad-spectrum lighting. Corrected the misleading narration sentence about “their light.” Kept the synchronized colour/matte records and later printing distinct.
- **Three Vlahos patents:** checked inventor, title, number, filing and grant dates against the patent records. Colour difference: filed 2 April 1959, granted 24 November 1964. Sodium: filed 15 May 1958, granted 25 June 1963. Electronic: filed 25 September 1975, granted 8 February 1977.
- **Recognition:** kept awards years separate from presentation years: the shared Vlahos–Pohl–Iwerks technical award belongs to 1964, presented in 1965; Petro and Paul’s Ultimatte award belongs to 1994, presented in 1995. The Gordon E. Sawyer listing remains explicitly labelled as an awards year. Added the Academy’s Mary Poppins ceremony record [17] to distinguish the film’s Special Visual Effects award, credited to Ellenshaw, Lycett and Luske, from the technical award.
- **Attribution:** retained Vlahos’s optical contribution, Iwerks’s camera/production role, Pohl’s documented shared recognition and the independent British Rank lineage. No exclusive invention claim or invented allocation of Pohl’s engineering work was added.
- **Context:** connected engineering and shared laboratory work directly to Vlahos. Paramount, HUAC, Cold War pressure and labour conflict are broader industry context. No personal HUAC involvement, military funding of his matte inventions or radar-to-prism technical derivation is asserted.
- **Modern systems:** retained Bayer sampling, demosaicing, RGB values and alpha in optional notes. Film densities, electronic signals and digital pixels are distinguished. The 2024 reconstruction is described using its official SIGGRAPH abstract, not as archival evidence for the original invention.

## Editorial changes

The introduction now names Vlahos’s contributions directly. The biography follows his route between employers and institutions. Technical sections explain why he developed each system and how production needs shaped it. Ultimatte is presented as a continuation of his research, including television use, rather than a disconnected definition of keying.

Removed dramatic taglines, repeated explanations of edge defects and invention myths, duplicated political-context caveats and repeated prism-count discussions. Consolidated the prism discrepancy into one optional note. Removed the unused second Q&A dataset so stale answers cannot disagree with the displayed 24. Specialist material remains in optional technical notes; the main demonstrations and explanatory process strip remain intact.

Removed “THE RESEARCH,” “THE ARGUMENT,” “Following the evidence” and the generic sidebar fallback. Sidebars now identify early career, earlier compositing, Ben-Hur, the Disney collaboration and Ultimatte. Captions identify the subject concisely. Photograph provenance uncertainties and redistribution workflow notes remain in the manifest/documentation; creator credits, licence links and adaptation notices remain available. Assignment administration was removed from References and the exported script.

## Citation review and replacement links

Every bibliography entry was opened and its relevance checked, with access limits distinguished below. Media source pages were inspected against the captions. A separate fresh request check of all **23 unique media source/original URLs** returned HTTP 200. That status check supplements content inspection; it is not a substitute for it. Machine-readable request results are in `artifacts/editorial-media-urls.json` and `artifacts/editorial-source-urls.json`.

| Source | Result |
| --- | --- |
| [1] Los Angeles Times | Article and published correction accessible; biography and corrections checked. |
| [2–4] Vlahos patents | All three accessible; specifications, dates, inventors and drawings checked. |
| [5] Foster/Wiley excerpt | Accessible PDF. Added printed page references for the interview, Ben-Hur, Ultimatte and optics. Recollections are compared with institutional records. |
| [6] Academy database | Replaced generic home with the official Class I/Award of Merit results list containing both relevant entries. Added Find-in-page and search fallback instructions. Individual nomination links did not reliably resolve. The list was readable through web retrieval; a separate direct request returned 403. |
| [7] Disney archive article | Accessible; publication date, prism photograph, Mary Poppins comparison and three-prism statement checked. |
| [8] Fratini/ASC | Accessible; industry context and image captions checked. The CinemaScope 55 image caption explicitly identifies summer 1955, despite “1953” in the image filename. |
| [9] Academy announcement/CGW | Article readable through web retrieval; direct request returned 403. Career honours and film examples checked against its text. |
| [10] Corridor Crew | Video ID/title and availability checked; web retrieval did not expose a complete playable transcript. Do not treat this as a frame-by-frame verification of the full video. Technical details are supported independently by [14]. |
| [11] Teledyne | Article readable through web retrieval; direct request returned 403. Bayer/filter-array explanation checked. |
| [12] Harryhausen/ASC | Replaced staging link with the working ASC article. Identified Ann Tasker, the original June 1981 interview and 23 February 2022 online date. Rank discussion checked. |
| [13] VES handbook | Original Routledge product URL returned 403, not proof of a dead page. Replaced with publisher’s accessible third-edition companion page. Editors, ISBN and 2020 edition confirmed against Routledge’s filmmaking catalogue. Complete book not read; retained as further reading. |
| [14] Debevec/Pueringer | Replaced homepage with official SIGGRAPH 2024 proceedings abstract, linked to its title using a text fragment. Title, authors, beam splitter, filters and synchronized digital cameras verified. ACM full text returned 403. A separate direct request to SIGGRAPH encountered a redirect restriction, while web retrieval supplied the full proceedings abstract. |
| [15] DOJ | Accessible government account; Paramount decision and decrees checked. |
| [16] Wisconsin archive | Accessible institutional exhibit; HUAC/blacklist context checked. |
| [17] Academy 1965 ceremony | Readable through web retrieval; separate direct request returned 403. Film’s effects award recipients checked. |
| [18] OpenEXR documentation | Accessible official technical documentation; RGB and alpha/opacity definitions checked. Added to support digital-compositing explanations directly rather than cite sensor information for opacity. |

Replaced original URLs, retained here for traceability:

- [6] `https://awardsdatabase.oscars.org/` → official Award of Merit results list in `src/data/sources.ts`.
- [12] `https://staging.ascmag.com/articles/ray-harryhausen-talks-about-his-cinematic-magic` → [ASC article](https://theasc.com/article/ray-harryhausen-talks-about-his-cinematic-magic/).
- [13] `https://www.routledge.com/9781138542204` → [publisher’s third-edition companion](https://routledgetextbooks.com/textbooks/9781138542204/default.php). Edition metadata also appears in the [publisher’s catalogue](https://www.routledge.com/rsc/catalog_pdfs/Filmmaking_and_Postproduction_Fall_2025_GBP.pdf).
- [14] `https://www.pauldebevec.com/` → [SIGGRAPH proceedings abstract](https://www.siggraph.org/wp-content/uploads/2025/08/Posters-24.html#:~:text=Recreating%20the%20Sodium%20Vapor%20Matting%20Process). Full paper DOI: `10.1145/3641234.3671046`.

The background photograph’s Commons page could not be opened by the web retrieval tool, but an independent request retrieved its content and confirmed Nicholas A. Tonelli’s credit and CC BY 2.0 licence. PictureYouth’s source and the licence deed were accessible. The portrait’s photographer and date remain unidentified by its reproducing site.

## Narration and recordings

The canonical current script is `src/data/narration/*.txt`. The player imports those exact files, and `npm run media` regenerates `public/recording-script.txt` from them. All five chapters were revised: shorter introduction, clearer career transition and context, production-led colour-difference explanation, corrected sodium lighting and collaborative credit, and a clearer Ultimatte/legacy ending. The original refined research script is preserved as a historical input, not a second current transcript.

**668 spoken words**, counted by whitespace, excluding headings, citations, filenames and download instructions. Budget about 4:46 at 140 wpm, leaving roughly 14 seconds within five minutes for brief pauses; rehearse at your own pace and keep demonstration stops brief. Slower delivery will need fewer live demonstration stops.

**No user recordings were present: 0/5 available.** All five revised scripts need recordings if recorded narration is desired. Older recordings held elsewhere may no longer match any chapter; compare or re-record all five. No AI narration was generated. Audio QA used the repository’s temporary, explicitly labelled test tones; these were removed afterward.

## Unresolved research / personal review

- Pohl’s exact individual engineering role remains insufficiently documented in this source set. The site gives the official joint recognition and does not assign him an unsupported component.
- Foster’s single-prism story and Disney’s three-produced statement differ. Neither establishes an exact surviving count.
- Read the full ACM paper through library access if discussing details beyond the official abstract. The full Corridor video and VES book also require personal review if used for additional claims or clips.
- Rehearse the 668-word script with the intended demonstration pauses. Record/add audio if desired; missing-audio transcript fallback is functional.
- Existing manifest rights records still identify copyrighted reference images whose public redistribution has not been cleared. No publication/deployment was performed; asset permissions and the unidentified portrait credit remain matters for review before public redistribution.

## Fresh validation

Earlier reports in the repository were not used as evidence of current behaviour.

- TypeScript: `npx.cmd tsc --build` — passed.
- Lint: `npm.cmd run lint` — passed.
- Automated content tests: `npm.cmd test` — all **6 passed**, including all citation IDs, source replacement traceability, media records, narration length and exact export/transcript consistency.
- Production: `npm.cmd run build` — passed. The compiled site was served separately with Vite preview and passed all **33 browser checks**.
- The same **33 browser checks** passed at desktop and 390-pixel mobile widths during development. They cover navigation, themes, local historical images/fonts, citation targets, all RGB modes, actual changed composite pixels, both demonstration samples, all sodium optical steps and missing-audio fallback.
- Audio: **13 browser checks passed** using temporary WAV test tones: real duration, play/pause, seeking, speed, chapter transitions, pausing on references and transcript fallback. Fixtures removed; final availability is **0/5 recordings**. User recordings could not be tested because none were present.
- Layout: all eight narrative/Q&A/reference anchors checked at **1440×1000**, **518×844** and **390×844**, with no page overflow or unintended overflowing content. Horizontal scrolling remains confined to the intended sodium-diagram region. Desktop/mobile screenshots inspected, including dark-theme biography detail; no major gaps from the edits were found.
- Browser console: no errors reported on the checked page. All 15 rendered historical figures and the two demonstration photographs loaded locally.
- `git diff --check` — passed. No redesign, animations or generated narration added.

Two pre-existing test expectations were revised to match the task: obsolete source URLs are now preserved in this report rather than required in the public bibliography, and research no longer has an arbitrary minimum of five times the narration length. The browser test now recognizes the concise illustrated-composite caption. Citation and export checks were strengthened.
